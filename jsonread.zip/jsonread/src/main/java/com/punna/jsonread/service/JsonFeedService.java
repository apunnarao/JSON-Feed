package com.punna.jsonread.service;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.punna.jsonread.bean.DataBean;

@Service
public class JsonFeedService {

	public List<DataBean> update4thElement(List<DataBean> feedData) {
		int count = 1;
		for (Iterator<DataBean> iterator = feedData.iterator(); iterator.hasNext();count++) {
			DataBean dataBean = iterator.next();
			if(count == 4) {
				dataBean.setTitle("1800Flowers");
				dataBean.setBody("1800Flowers");
				break;
			}
		}
		return feedData;
	}
	
	public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
		Map<Object, Boolean> uniqueMap = new ConcurrentHashMap<>();
		return t -> uniqueMap.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
	}
	
	public Integer getDistinctUserIdCount(List<DataBean> feedData) {
		return feedData.stream().filter(distinctByKey(cust -> cust.getUserId()))
				.collect(Collectors.toList()).size();
	}
}

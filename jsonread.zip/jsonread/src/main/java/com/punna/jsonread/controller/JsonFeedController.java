package com.punna.jsonread.controller;

import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.punna.jsonread.bean.DataBean;
import com.punna.jsonread.service.JsonFeedService;

@RestController
@RequestMapping("/jsonfeed")
public class JsonFeedController {

	@Autowired
	JsonFeedService feedService;
	
	static List<DataBean> feedData;
	
	static {
		ResponseEntity<List<DataBean>> data = new RestTemplate().exchange("http://jsonplaceholder.typicode.com/posts", HttpMethod.GET,null, new ParameterizedTypeReference<List<DataBean>>() {});
		feedData = data.getBody();
		System.out.println(feedData.size());
	}
	
	@GetMapping(value="/count")
	public Integer getCount() {
		return feedService.getDistinctUserIdCount(feedData);
		  
	}
	@PutMapping(value="/updatedUserList")
	public List<DataBean> updateUserList() {
		feedData = feedService.update4thElement(feedData);
		return feedData;
	}
	
	
}

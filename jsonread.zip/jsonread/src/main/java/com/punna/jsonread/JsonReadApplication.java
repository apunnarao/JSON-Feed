package com.punna.jsonread;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class JsonReadApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonReadApplication.class, args);
	}

}
